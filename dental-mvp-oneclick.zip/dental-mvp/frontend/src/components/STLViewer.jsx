import React, { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader.js'

export default function STLViewer({ fileUrl }) {
  const mountRef = useRef(null)

  useEffect(()=>{
    const width = mountRef.current.clientWidth
    const height = 420

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(45, width/height, 0.1, 1000)
    camera.position.set(0, 0, 120)

    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setSize(width, height)
    mountRef.current.appendChild(renderer.domElement)

    const light = new THREE.DirectionalLight(0xffffff, 1)
    light.position.set(1,1,1)
    scene.add(light)
    scene.add(new THREE.AmbientLight(0xffffff, 0.4))

    const loader = new STLLoader()
    loader.load(fileUrl, (geometry)=>{
      geometry.center()
      const material = new THREE.MeshNormalMaterial()
      const mesh = new THREE.Mesh(geometry, material)
      mesh.rotation.x = -Math.PI/2
      scene.add(mesh)

      const animate = ()=>{
        requestAnimationFrame(animate)
        mesh.rotation.z += 0.005
        renderer.render(scene, camera)
      }
      animate()
    })

    const handleResize = ()=>{
      const w = mountRef.current.clientWidth
      camera.aspect = w/height
      camera.updateProjectionMatrix()
      renderer.setSize(w, height)
    }
    window.addEventListener('resize', handleResize)

    return ()=>{
      window.removeEventListener('resize', handleResize)
      mountRef.current.removeChild(renderer.domElement)
    }
  }, [fileUrl])

  return <div ref={mountRef} style={{width:'100%'}} />
}
