import React, { useState } from 'react'

export default function PatientForm({ onSaved }) {
  const [form, setForm] = useState({ name: '', age: '', anamnesis: '' })
  const [photo, setPhoto] = useState(null)
  const [stlFile, setStlFile] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    const data = new FormData()
    data.append('name', form.name)
    data.append('age', form.age)
    data.append('anamnesis', form.anamnesis)
    if (photo) data.append('photo', photo)
    if (stlFile) data.append('stlFile', stlFile)

    const res = await fetch('/api/patients', { method: 'POST', body: data })
    const json = await res.json()
    onSaved && onSaved({ photo: json.photoUrl, stl: json.stlUrl })
    alert('Patient gespeichert!')
  }

  return (
    <form onSubmit={handleSubmit}>
      <label>Name</label>
      <input type="text" value={form.name} onChange={e=>setForm(f=>({...f, name:e.target.value}))} placeholder="Max Mustermann" />
      <label>Alter</label>
      <input type="number" value={form.age} onChange={e=>setForm(f=>({...f, age:e.target.value}))} placeholder="35" />
      <label>Anamnese</label>
      <textarea rows="3" value={form.anamnesis} onChange={e=>setForm(f=>({...f, anamnesis:e.target.value}))} placeholder="Kurze Anamnese" />
      <label>Patientenfoto</label>
      <input type="file" accept="image/*" onChange={e=>setPhoto(e.target.files[0])} />
      <label>Intraoralscan (STL)</label>
      <input type="file" accept=".stl" onChange={e=>setStlFile(e.target.files[0])} />
      <div style={{marginTop:12}}>
        <button type="submit">Speichern</button>
      </div>
    </form>
  )
}
