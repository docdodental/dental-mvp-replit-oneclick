import React, { useState } from 'react'
import PatientForm from '../components/PatientForm.jsx'
import STLViewer from '../components/STLViewer.jsx'

export default function App() {
  const [activeTab, setActiveTab] = useState('fotos')
  const [stlUrl, setStlUrl] = useState(null)
  const [photoUrl, setPhotoUrl] = useState(null)

  return (
    <div className="container">
      <h1>Digitale Patientenakte (MVP)</h1>
      <div className="card">
        <div className="grid">
          <div>
            <div className="thumb">{photoUrl ? <img src={photoUrl} alt="Patient" style={{width:'100%', height:'100%', objectFit:'cover', borderRadius:8}}/> : 'Patientenfoto'}</div>
          </div>
          <div>
            <PatientForm onSaved={({photo, stl})=>{
              if (photo) setPhotoUrl(photo);
              if (stl) setStlUrl(stl);
            }}/>
          </div>
        </div>

        <div className="tabs">
          <div className={`tab ${activeTab==='fotos'?'active':''}`} onClick={()=>setActiveTab('fotos')}>Fotos</div>
          <div className={`tab ${activeTab==='viewer'?'active':''}`} onClick={()=>setActiveTab('viewer')}>3D-Viewer</div>
          <div className={`tab ${activeTab==='labor'?'active':''}`} onClick={()=>setActiveTab('labor')}>Laborfälle</div>
          <div className={`tab ${activeTab==='docs'?'active':''}`} onClick={()=>setActiveTab('docs')}>Dokumente</div>
        </div>

        {activeTab==='viewer' && (
          <div style={{marginTop:16}}>
            {stlUrl ? <STLViewer fileUrl={stlUrl}/> : <p>Bitte einen Intraoralscan (STL) hochladen.</p>}
          </div>
        )}

        {activeTab==='fotos' && (
          <div style={{marginTop:16}}>
            {photoUrl ? <img src={photoUrl} alt="Foto" style={{maxWidth:'100%', borderRadius:8}}/> : <p>Noch kein Foto hochgeladen.</p>}
          </div>
        )}
      </div>
    </div>
  )
}
