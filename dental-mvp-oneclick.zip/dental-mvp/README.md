# Dental MVP (One-click Run for Replit)

- **Frontend:** React + Vite + Three.js (STL Viewer)
- **Backend:** Express + Multer (Upload)
- **One-click:** Press **Run** in Replit. `run.sh` installiert Abhängigkeiten (einmalig) und startet beide Prozesse.

## Lokaler Start (optional)
```
npm install
npm run dev
```
