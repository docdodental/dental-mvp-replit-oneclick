#!/usr/bin/env bash
set -e

# Install once (cached by Replit)
if [ ! -d "node_modules" ]; then
  npm install
fi

# Also install workspace deps (frontend/backend)
if [ ! -d "frontend/node_modules" ]; then
  (cd frontend && npm install)
fi
if [ ! -d "backend/node_modules" ]; then
  (cd backend && npm install)
fi

# Start both (frontend + backend)
npm run dev
